#import <React/RCTBridgeModule.h>

@interface RNAuthorizeNet : NSObject <RCTBridgeModule>

@end
  
