import { NativeModules } from 'react-native'

const { RNAuthorizeNet } = NativeModules

export default RNAuthorizeNet
